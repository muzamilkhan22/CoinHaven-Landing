// ✅ Waitlist Form Submission
document.getElementById('waitlist-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const email = this.querySelector('input').value;
    if (email) {
      alert(`Thanks! We'll notify you at ${email} when CoinHaven is live.`);
      this.reset();
    } else {
      alert('Please enter a valid email address.');
    }
  });
  
  // ✅ Swiper Carousel for Testimonials
  const swiper = new Swiper('.testimonials-swiper', {
    loop: true,
    slidesPerView: 1,
    spaceBetween: 30,
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    breakpoints: {
      768: { slidesPerView: 2 },
      1024: { slidesPerView: 3 }
    }
  });
  
  // ✅ Initialize AOS (Animate on Scroll)
  AOS.init({
    duration: 800,
    once: true
  });
  